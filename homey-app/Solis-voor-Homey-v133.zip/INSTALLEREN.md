# Solis voor Homey – installeren (stap voor stap)

Zie ook de handleiding (PDF) in dezelfde map.

## Eenmalig voorbereiden
1. Installeer **Node.js** (LTS) van https://nodejs.org.
2. Terminal: `npm install -g homey`
3. Log in: `homey login`

## De app op je Homey zetten
4. Pak de zip uit. Ga in Terminal naar de map `homey-app`.
5. **Eerst één keer:** `npm install` (haalt het onderdeel voor de P1-koppeling binnen).
6. Dan: `homey app install`. Kies je Homey Pro. Bevestig de toestemmingen (Homey API en locatie).

## Toevoegen en instellen
7. Homey-app → Apparaten → **+** → Solis voor Homey → Solis-omvormer.
8. Tandwiel → vul het **IP-adres van de datalogger** in. Poort 502, Modbus-ID 1.
9. P1-dongle: staat standaard aan en zoekt zelf de Homey Energy Dongle.

## Na een nieuwe versie
Wacht 5 minuten voor je de stand aanpast. De datalogger heeft even nodig om de oude verbinding los te laten.

## Dashboard op je Mac (versie 3.8)
De app heeft nu een eigen dashboard, zonder extra programma's of API-sleutel.
1. Installeer de app (`homey app install`) en wacht 5 minuten.
2. Open op je Mac in een browser: `http://<IP-adres van je Homey>:8765`
3. Kies bovenin Zonnebaan of Energiestroom (of druk op 1 of 2). Druk op F voor volledig scherm.
4. Safari: Bestand, Voeg toe aan Dock, dan heb je er een eigen venster van.
Instellingen (aan/uit, poort, standaardstijl) staan in de apparaat-instellingen onder Dashboard.

## Instellingen (versie 3.9)
Alle algemene instellingen (contract, meldingen, prijzen, P1, kosten, dashboard) staan nu in de app zelf: Homey-app, Meer, Apps, Solis voor Homey, knop Instellingen. In het tandwiel van het Solis-apparaat staan alleen nog de dingen van de omvormer zelf: verbinding, aansturen en panelen. Je oude instellingen worden bij de eerste start automatisch overgenomen.

## Dashboard: vier stijlen (versie 3.10)
Zonnebaan, Energiestroom, Details (opwek en verbruik per uur, score en records, uurprijzen, apparaten, besparing) en Rondgang (wisselt vanzelf, handig voor een wandscherm). Toetsen 1 tot 4 wisselen van stijl, F is volledig scherm. Bij een wandscherm dimt het scherm als de zon onder is, en de pagina herstelt zichzelf bij storingen.

## Nieuw in 3.11
- Dashboard-pagina Inzicht (toets 4; Rondgang is nu toets 5): laatste 14 dagen, verwachting voor 3 dagen met weer, terugverdiend, schaduw en vuil, terugleveren, laadtip.
- Meldingen: nieuw record, eerste negatieve prijs van het jaar, gevolgd apparaat klaar.
- Back-up: in de Instellingen van de app (kopieer de tekst) of als bestand via http://IP-VAN-JE-HOMEY:8765/backup.json

## Nieuw in 3.12
Alles staat bij Instellingen van de app (niet bij het apparaat).
- **Zelfverbruik-sturing** (Instellingen, Zelfverbruik-sturing): de app zet apparaten zoals een boiler aan als je zonne-overschot hebt en weer uit bij stroom van het net. Staat standaard UIT en in testmodus: in het logboek zie je dan wat de app zou doen. Zet testmodus pas uit als dat klopt. De app schakelt alleen uit wat hij zelf aanzette.
- **Planner**: vul bij Planner bijvoorbeeld `Vaatwasser, 2, 1800; Wasmachine, 2, 700` in (naam, uren, vermogen). Je ziet het beste tijdstip op het dashboard (Inzicht en Overzicht).
- **Overzicht** (nieuwe dashboardpagina): jaar, maand, opbrengst per maand en "Wat als?" (kosten nu, vast zonder saldering, vast met saldering). Onderaan staat "Afdrukken of opslaan als PDF".
- **Pagina's en volgorde** van het dashboard: instelbaar bij Dashboard, Pagina's en volgorde. Ook bepaalt dit de Rondgang. Tijdelijk kan met `?p=zon,overzicht` achter het adres.
- **Ochtendsamenvatting**: elke ochtend (standaard 08:00) een melding met verwachting, gisteren, plan en eventuele problemen.
- Tijdlabels onder de prijsgrafiek staan nu op de juiste plek.

## Nieuw in 3.13
- **Dure uren**: een half uur van tevoren een melding als stroom duur wordt (dynamisch contract). Grens instelbaar bij Meldingen, standaard automatisch.
- **Afwijkingen**: melding als het huis een dag veel meer stroom gebruikte dan normaal, of de opbrengst veel lager was dan het weer deed verwachten.
- **Jaarvergelijking**: het Overzicht zet dit jaar naast vorig jaar (zodra er vorig jaar gegevens zijn). De app bewaart nu twee jaar aan dagen.
- **Telefoon**: open het dashboard op je telefoon (zelfde adres, op je thuisnetwerk). Op een smal scherm krijg je automatisch een eigen verticale weergave.

## Nieuw in 3.14
- **Vakantiestand** (Instellingen, Meldingen): stopt dagelijkse berichten, tips en de sturing. Storingen, geen opbrengst, hoge temperatuur en ongewoon verbruik blijf je krijgen. Optioneel een einddatum. Ook te zetten met de flowkaart "Zet vakantiestand aan/uit".
- **Maandrapport**: op de 1e van de maand een melding met de cijfers van de vorige maand, inclusief vergelijking met vorig jaar.
- **Thuisbatterij?** (Overzicht): schat of 5 of 10 kWh batterij zich terugverdient, op basis van jouw eigen dagen en je vaste tarieven (zonder saldering). Alleen een rekenhulp: de app stuurt geen batterij aan.
- **Nieuwe flowkaarten** voor scènes: "Het goede moment om apparaten te starten is voorbij", "Stroom wordt zo duur" (met van, tot en prijs) en de voorwaarde "Vakantiestand staat aan".

## Nieuw in 3.15
- **Geschiedenis uit Homey overnemen**: de app leest de meterstanden die Homey zelf bewaart (omvormer en P1) en maakt daar eerdere dagen van voor het Overzicht. Dit gebeurt één keer vanzelf, kort na de eerste start. Je kunt het opnieuw doen via Instellingen, "Geschiedenis uit Homey ophalen", of met de flowkaart "Haal geschiedenis uit Homey op". Alleen dagen die de app nog niet kent worden toegevoegd. Overgenomen dagen bevatten opwek, afname en teruglevering, maar geen euro's. Waarde en kosten zijn daardoor pas vanaf de eerste dag dat de app zelf meet echt gevuld.
- **Overzicht helemaal vernieuwd**: grote kerncijfers (opgewekt, zelfverbruik met ring, waarde, terugverdiend), een nette maandgrafiek met vorig jaar erbij, een visuele "Wat als?"-vergelijking, de batterij-rekenhulp, de maandcijfers en het plan.

## Nieuw in 3.15.1
- Overgenomen dagen uit Homey krijgen nu ook geschatte euro's, berekend met je vaste tarieven (Instellingen, Kosten en apparaten). Daardoor tellen ze mee in waarde van je zonnestroom, netto kosten en terugverdientijd. Vul eerst de tarieven in en haal de geschiedenis daarna opnieuw op (Instellingen, "Geschiedenis uit Homey ophalen").
- Het Overzicht laat zien hoeveel dagen uit Homey komen.

## Nieuw in 3.15.2
- Het overnemen uit Homey zoekt de zon-opbrengst nu op meer manieren: de meterstand, de dagopbrengst en het vermogen van de omvormer, en ook andere zonnepaneel-apparaten in Homey (bijvoorbeeld een eerdere koppeling). Eerder overgenomen dagen zonder opbrengst worden aangevuld.
- De melding na het ophalen laat per bron zien hoeveel dagen er gevonden zijn.

## Nieuw in 3.15.3
- Bij het overnemen uit Homey tellen lege stukken in de logboeken (null) niet meer als 0. Daardoor ging de zon-opbrengst eerder mogelijk verloren. De melding na het ophalen laat nu bij bronnen zonder waarden ook zien hoeveel echte punten erin zitten en wat de hoogste waarde is.

## Nieuw in 3.16
- **Opbrengst van vroeger schatten**: Homey bewaart van je omvormer geen dagwaarden van voor de installatie van deze app, alleen de totaalteller. De app neemt dat totaal (de levenslange meterstand van de omvormer), trekt af wat hij zelf gemeten heeft, en verdeelt de rest over de eerdere dagen naar rato van de zonnestraling per dag (Open-Meteo). Een dag wekt nooit minder op dan er is teruggeleverd. Het totaal klopt dus, de verdeling per dag is een schatting. Het Overzicht noemt hoeveel dagen geschat zijn.
- Dit gebeurt bij "Geschiedenis uit Homey ophalen" (Instellingen). Het weerarchief gaat maximaal 92 dagen terug.

## Nieuw in 3.16.1
- Als de weerdienst bij het schatten van de opbrengst een fout geeft (bijvoorbeeld HTTP 503), probeert de app het opnieuw en valt daarna terug op het weerarchief. Lukt dat ook niet, dan zegt de melding dat je het later opnieuw kunt proberen.

## Nieuw in 3.16.2
- Als Open-Meteo niet te bereiken is, haalt de app de zonnestraling voor het schatten van de opbrengst bij NASA POWER (gratis, zonder sleutel). Alleen de verhouding tussen dagen telt, dus het maakt niet uit welke bron het is.

## Nieuw in 3.16.3
- Lukt het ophalen van weergegevens niet, dan schat de app de opbrengst zonder weer: opwek is dan de teruglevering van die dag plus een gelijk deel van het eigen gebruik (totaal van de omvormer min alle teruglevering, gelijk verdeeld over de dagen). Het totaal blijft kloppen met de meterstand van je omvormer. De melding zegt welke manier gebruikt is.

## Nieuw in 3.16.4
- De geschatte opbrengst begint nu pas bij de eerste echte periode met teruglevering (los getal van meter-ruis eerder wordt genegeerd). Haal daarna de geschiedenis opnieuw op.

## Nieuw in 3.17.0
- **Pagina Dynamisch** op het dashboard: hoeveel dagen tot 1 januari 2027, gemiddelde prijs van morgen, goedkoopste en duurste 3 uur, prijs per uur, wat jouw verbruik dynamisch kost tegenover vast, en wat slim verschuiven per jaar oplevert. Zet "dynamisch" in Instellingen bij Pagina's en volgorde (staat standaard aan voor nieuwe installaties).
- **Melding bij negatieve prijs morgen** (aan/uit in Instellingen) en een nieuwe flow-trigger "Morgen negatieve stroomprijs" met tokens Van en Tot.
- **Jaaroverzicht als PDF**: op de pagina Overzicht staat rechtsonder een link. Op de pagina die opent klik je "Opslaan als PDF". Dit adres werkt ook direct: http://IP-VAN-JE-HOMEY:8765/jaar
- **SolisCloud**: vul bij Instellingen de KeyID en KeySecret in (te vragen via SolisCloud, Account, API-beheer; soms eerst aan te vragen bij Solis-support) en druk op "Dagopbrengst uit SolisCloud ophalen". Geschatte dagen worden dan vervangen door de echte opbrengst. Eigen gemeten dagen blijven ongewijzigd. Ook als flow-actie beschikbaar.
- De ochtendmelding noemt nu ook de verwachting van morgen; het Overzicht toont die bij Plan en sturing.

## Nieuw in 3.18.0
- **Batterij bij dynamisch** op de pagina Dynamisch: opbrengst per jaar en terugverdientijd (5 en 10 kWh) uit het prijsverschil van de komende dag.
- **Terugleverkosten-bewaker**: vul bij Instellingen "Kosten per teruggeleverde kWh" in. De pagina Dynamisch en het maandrapport laten zien of terugleveren je netto geld kost.
- **Planner met deadline**: noteer bijvoorbeeld `Laadpaal, 5, 7400, 07:00`. Het laatste getal is het uur waarop het klaar moet zijn. Tot 12 uur lang kan, dus ook auto of warmtepomp.
- **Sneeuw en storing**: bij een lage opbrengst noemt de melding een mogelijke oorzaak (sneeuw, mist, ijzel, of controleer de omvormer).
- **Zon-score** (100 = normaal voor jouw panelen) en **vergelijking met een gemiddelde installatie**: op de pagina Dynamisch en bij Plan en sturing op het Overzicht.
- **Prijsalarm**: zet het aan in Instellingen en kies een grens. Je krijgt één melding als de prijs eronder zakt, plus een flow-trigger "Stroomprijs onder alarmgrens".
- **Nieuwe widget "Solis Prijs en zon-score"** voor je Homey-startscherm.

## Nieuw in 3.18.1
- De tab Dynamisch verschijnt nu vanzelf bij wie de standaard paginalijst heeft. Wie zelf pagina's koos, zet `dynamisch` erbij in Instellingen.

## Nieuw in 3.19.0
- **Nieuwe telefoonversie** van het dashboard (open hetzelfde adres op je telefoon): vijf tabs onderaan (Nu, Prijzen, Overzicht, Dynamisch, Meer), licht en donker vanzelf naar je telefooninstelling, en je laatst gekozen tab wordt onthouden.
- De maker van de app is nu Wilfried van der Voort.

## Nieuw in 3.19.1
- Telefoonversie: geen nachtdimming meer (die maakte het scherm te donker en schoof de tabbalk uit beeld). Donker of licht volgt nu de instelling van je telefoon.

## Nieuw in 3.20.0
- **Donkere modus** voor het hele dashboard (Mac, tablet en telefoon). Standaard automatisch volgens je apparaat. Wil je het vast, kies bij Instellingen, Dashboard, "Licht of donker". Op het dashboard zelf wisselt de toets D tussen automatisch, donker en licht.

## Nieuw in 3.21.0

- **Automatische back-up**: elke nacht na 03:00 bewaart de app een kopie van je geschiedenis in Homey. Voeg je het apparaat ooit opnieuw toe, dan zet de app die kopie vanzelf terug. Let op: verwijder je de héle app, dan verdwijnt ook die kopie. Download daarom af en toe zelf een back-up (onderaan het dashboard, "Back-up downloaden"). Na ongeveer 6 weken zonder download krijg je een herinnering (uit te zetten bij Instellingen → Meldingen).
- **Dashboard als app op je iPhone**: open het dashboard in Safari, tik op Deel en kies "Zet op beginscherm". Je krijgt een zon-icoon en het dashboard opent schermvullend.
- **Factuurcontrole**: vul bij Instellingen → Factuurcontrole de maand (bijv. 2027-01) en de kWh-aantallen van je factuur in. De app vergelijkt dat met zijn eigen metingen en stuurt een melding. Op de telefoon (tab Meer) zie je ook altijd de totalen van vorige maand.
- **Jaarterugblik**: op 31 december (na 18:00) krijg je een samenvatting van het jaar, met vergelijking met vorig jaar en contract. Uit te zetten bij Meldingen.

## Nieuw in 3.21.1

- De zon op de Zonnebaan verdwijnt nu na zonsondergang en voor zonsopkomst (hij bleef eerst als bleke bol zichtbaar).

## Nieuw in 3.21.2

- De zon en de gloed verdwijnen nu echt na zonsondergang (de gloed had een pulserende animatie die het verbergen tegenhield).

## Nieuw in 3.22.0

- **Apparaten die leren**: de app volgt hoe lang een wasbeurt (of elk ander programma) duurt, hoeveel kWh het kost en welke programma's je gebruikt (bijvoorbeeld Eco en Intensief). Je ziet dit op de telefoon onder Meer, kaart "Apparaten". Na 3 beurten telt het als geleerd.
- **Slimme stekkers automatisch volgen**: zet bij Instellingen → Kosten en apparaten "Alle slimme stekkers met vermogensmeting automatisch volgen" aan. Elke stekker die het verbruik meet wordt dan gevolgd en geleerd, ook nieuwe die je later toevoegt.
- **Planner gebruikt wat hij geleerd heeft**: de echte duur en het echte vermogen gaan voor je schatting. Wasmachine, vaatwasser, droger en laadpaal worden vanzelf ingepland zodra de app ze kent (uit te zetten bij Planner).
- **Nieuwe flow-kaart "Beste moment voor ...."** (Wanneer-kaart): gaat af zodra het goedkoopste blok begint. Zet er een flow aan die de slimme stekker van je wasmachine aanzet. De kaart heeft de tag Apparaat. Gebruik een logica-kaart (Apparaat is Wasmachine) om één apparaat te kiezen.
- **Bespaard bij negatieve prijs**: de app telt hoeveel stroom hij niet heeft teruggeleverd toen dat geld kostte, en wat dat scheelde (tab Dynamisch).
- **Jij tegenover vast contract**: per dag wat je echt betaalde tegenover een vast contract, met je beste en slechtste dag (tab Dynamisch, vul bij Instellingen je vaste tarief in).
- **Gezondheid panelen**: laatste 7 dagen tegenover de maand daarvoor, met uitleg (tab Meer).
- **Vakantie**: komt je vakantiestand tot een einde, dan krijg je een samenvatting van wat er die dagen gebeurde.
- **Zelfcontrole**: de dagelijkse controle meldt nu ook als de P1-meter niets meer doorgeeft of als een dag niet klopt (meer teruglevering dan opwek).

## Nieuw in 3.22.1

- Fout in de flow-kaart "Beste moment" hersteld (Homey keurde hem af bij het installeren). Kies het apparaat nu met een logica-kaart op de tag Apparaat.

## Nieuw in 3.23.0

- **Keuzelijst voor apparaten**: bij Instellingen onderaan staat "Apparaten kiezen". Druk op Apparaten zoeken, vink aan welke apparaten de app moet volgen en leren (slimme stekkers staan bovenaan, je ziet ook hoeveel watt ze nu gebruiken), druk op Toepassen en daarna op Opslaan.

## Nieuw in 3.23.1

- **Testmelding**: bij Instellingen staat de knop "Stuur een testmelding" (ook als Flow-actie). Zo zie je meteen of meldingen op je telefoon aankomen.

## Nieuw in 3.23.2

- De thuisbatterij-rekenhulp zegt "verdient zich niet terug" in plaats van een absurde terugverdientijd (boven 40 jaar).

## Nieuw in 3.23.3

- Lange meldingen op de telefoon (zoals de factuurcontrole) staan nu netjes in een afgeronde balk in plaats van over de rand.

## Nieuw in 3.23.4

- Geen meldingen meer als de omvormer in de avond of nacht slaapt: "niet bereikbaar" komt alleen nog tussen 09:00 en 16:00, hooguit eens per 2 uur, en "hersteld" alleen als je de eerste melding ook kreeg.

## Nieuw in 3.24.0

- **Meldingen als pushmelding op je telefoon**: de app zet meldingen op de tijdlijn van Homey, maar Homey stuurt daar niet altijd een pushmelding bij. Nieuw is de Wanneer-kaart **"Solis melding"** (met de tag Tekst). Maak één flow:
  1. Open Flows in de Homey-app en maak een nieuwe flow.
  2. Kies bij Wanneer: Solis omvormer → Solis melding.
  3. Kies bij Dan: Meldingen → Stuur een pushmelding, en zet de tag Tekst erin.
  4. Sla op. Daarna komt elke melding van de app ook als pushmelding binnen. Test met de knop "Stuur een testmelding" bij Instellingen.

## Nieuw in 3.25.0

- **Wizard**: bovenaan de instellingen staat "Start de wizard". In 5 stappen kies je contract, tarieven (inclusief belasting en btw), apparaten en meldingen. De wizard slaat alles zelf op.
- **Factuurcontrole op het bedrag**: vul bij Factuurcontrole ook het totaalbedrag en je vaste kosten per maand in. De app vergelijkt dat met zijn eigen berekening (energiekosten uit de metingen plus de vaste kosten) en meldt of het klopt.
- **Terugleverkosten per periode**: bij Kosten en apparaten staat een nieuw veld, bijvoorbeeld `2027-01-01: 0,02; 2027-07-01: 0,04`. Het laatste bedrag dat al is gestart geldt.
- **Engels**: staat je Homey op Engels, dan zijn de instellingen (inclusief de wizard) in het Engels. Meldingen en het dashboard blijven voorlopig Nederlands.

## Nieuw in 3.26.0

- **Verbruik op het dashboard**: een nieuwe pagina "Verbruik" (Mac) en een kaart "Verbruik" onder het tabblad Overzicht (telefoon). Je ziet hoeveel stroom je huis gebruikt vandaag, deze maand en dit jaar, het gemiddelde per dag, een staafdiagram van de laatste 30 dagen (oranje = eigen zon, paars = van het net), het verbruik per uur van vandaag en het verbruik van de gevolgde apparaten. Het verbruik is opwek plus inkoop min teruglevering, dus de P1-meter moet werken.
- Staat bij Instellingen → Dashboard de lijst met pagina's op de standaard, dan komt Verbruik er vanzelf bij. Heb je zelf een lijst gemaakt, voeg dan `verbruik` toe.

## Nieuw in 3.26.1

- **Homey Energie bekijken**: bij Instellingen staat de knop "Homey Energie bekijken". Hij vraagt Homey Energie wat het voor vandaag meldt (verbruik, opwek) en zet dat naast de eigen berekening van de app. Homey beschrijft de velden van dit rapport niet; de knop laat daarom ook het begin van het rapport zien. Stuur die tekst naar mij, dan kan ik Homey's cijfers direct in het dashboard opnemen.

## Nieuw in 3.27.0

- **Verbruik uit Homey Energie op het dashboard**: Homey rekent het verbruik van je huis zelf uit. De app gebruikt dat nu voor "vandaag" (elke 5 minuten ververst) en voor eerdere dagen. Dat is nauwkeuriger dan de eigen berekening, die gaat bijvoorbeeld mis als de app midden op de dag herstart.
- **Eerdere dagen ophalen**: bij Instellingen staat de knop "Verbruik uit Homey Energie ophalen". Druk erop en wacht tot er staat hoeveel dagen binnen zijn. Staat er "nog X te gaan", druk dan nog een keer. Daarna haalt de app elke nacht vanzelf het verbruik van gisteren op.
- Op de Verbruik-pagina staat bij "Dit jaar" hoeveel dagen uit Homey Energie komen.

## Nieuw in 3.27.1
- Alle datums vul je nu in als **dd-mm-jjjj** (bijv. 01-01-2027) en maanden als **mm-jjjj** (bijv. 01-2027). De oude schrijfwijze werkt ook nog.
- Homey Energie bewaart geen rapport voor oudere dagen; die geven geen foutmelding meer, de app gebruikt daar haar eigen berekening.

## Nieuw in 3.28.0
- De app haalt nu ook de **maandtotalen** uit Homey Energie op (verbruik, ingekocht, teruggeleverd), tot 24 maanden terug. Dat is dezelfde data als de maandgrafiek in Homey Energie. Je ziet ze op de Verbruik-pagina onder "Per maand (Homey Energie)", en ze tellen mee in het jaartotaal.
- Druk na het installeren op "Verbruik uit Homey Energie ophalen". Daarna wordt het elke nacht bijgewerkt.

## Nieuw in 3.28.1
- "Opbrengst per maand" vult maanden waar de app zelf geen gegevens van heeft (bijv. januari t/m augustus) aan met de opwek uit Homey Energie.

## Nieuw in 3.29.0
- "Opbrengst per maand" is nu een tabel **Per maand** met opwek, verbruik, ingekocht en teruggeleverd (kWh) plus een totaalregel. Op de Mac in het Overzicht, op de telefoon bij Overzicht → Jaar. Maanden van vóór je zonnepanelen tonen alleen verbruik (uit Homey Energie).

## Nieuw in 3.29.1
- Tabel Per maand staat verder naar links en past nu volledig (ook de kolom Terug).
- Verbruik per maand wordt nu zelf uitgerekend (opwek + ingekocht - teruggeleverd), omdat het maandverbruik van Homey lager bleek dan wat er werd ingekocht. Druk na het installeren nog één keer op "Verbruik uit Homey Energie ophalen", dan worden alle maanden opnieuw berekend.

## Nieuw in 3.29.2
- Het kaartje Herkomst op de Verbruik-pagina is weer netjes: de maandenlijst is eruit gehaald (die staat in de tabel Per maand op Overzicht).

## Nieuw in 3.30.0: de pagina "Slim"
Op het dashboard (Mac) staat een nieuwe pagina **Slim**, en op de telefoon staan dezelfde kaarten bovenaan bij **Meer**:
1. **Sluipverbruik**: het minimale nachtverbruik van je huis (00:00-05:00), wat dat per jaar kost, en een melding als het omhoog gaat. Heeft een paar nachten P1-gegevens nodig.
2. **Opbrengst tegenover normaal**: vergelijkt de laatste 14 dagen met wat gebruikelijk is in Nederland. Vul hiervoor bij Instellingen het **vermogen van je panelen (kWp)** in, bijvoorbeeld 6 × 400 Wp = 2,4.
3. **Schaduw**: kijkt op zonnige dagen of de opbrengst op een vast uur wegzakt (boom, schoorsteen). Heeft een paar zonnige dagen nodig.
4. **Maandbudget**: stel bij Instellingen een maximum in voor de inkoop van het net (kWh per maand). Melding bij 80 %, als het budget op is, en als je er te snel doorheen gaat.
5. **Dynamisch contract in 2027**: schatting per jaar of dynamisch voor jou goedkoper of duurder is dan je vaste contract. Vul hiervoor je vaste tarief in (inclusief belasting en btw).
6. **Goed voor het milieu**: bespaarde CO2 en het aantal bomen dat dat zou opnemen (ruwe schatting).

## Nieuw in 3.30.1
- De knoppenbalk bovenaan het dashboard is kleiner en korter (Zon, Stroom, ...), zodat hij niet meer over de titel en de datum heen loopt nu er negen pagina's zijn.

## Nieuw in 3.31.0

### Instellingen overzichtelijk
- De instellingen staan nu in **inklapbare groepen** (Contract en tarieven, Installatie en doelen, Sturing, Vakantie, drie groepen Meldingen, Apparaten en planner, Koppelingen, Factuurcontrole, Dashboard). Tik op een kop om te openen of te sluiten.
- Bovenaan staat een **zoekvak**: typ bijvoorbeeld `kWp` of `melding` en je ziet alleen de passende instellingen.

### Dashboard: pagina "Opties" (alleen lezen)
Toont al je belangrijkste instellingen op één scherm, ook op de telefoon (onderaan Meer). Wijzigen doe je in de Homey-app. Het dashboard blijft bewust alleen-lezen: iedereen op je wifi kan het openen, dus er kan niets mee veranderd worden.

### Pagina "Slim": nu 12 kaarten
Nieuw bovenop de eerdere zes:
- **Nu per uur**: wat je op dit moment verdient of betaalt in euro per uur.
- **Netspanning**: hoe vaak de netspanning te hoog (253 V of meer) is geweest, waardoor de omvormer terugschakelt. Je krijgt één melding per dag als dat gebeurt.
- **Einde salderen**: wat je teruglevering met salderen waard was tegenover een gewone vergoeding. Vul hiervoor je vaste tarief in.
- **Doel en reeks**: stel bij Instellingen een dagelijks doel in (eigen gebruik in %). De app telt de dagen op rij en meldt reeksen van 3, 7, 14 en 30 dagen.
- **Tegenover een gemiddeld huishouden**: vul het aantal personen in huis in.
- **Verwachte jaaropbrengst**: vul het vermogen van je panelen (kWp) in.

### Meldingen die erbij zijn gekomen
- **Netspanning te hoog** (aan/uit bij Meldingen: storingen en controle).
- **Uitleg achteraf**: "Gisteren heb ik niet teruggeleverd toen de prijs negatief was, dat scheelde € X."
- **Onderhoudsherinnering** half maart en half oktober.
- **Goed moment** noemt nu welke apparaten van de overschot kunnen draaien (alleen als je die melding aan hebt).

### iPhone-widget (Snelkoppelingen)
Het dashboard heeft een korte tekstpagina: `http://IP-VAN-JE-HOMEY:8765/kort`, bijvoorbeeld: `☀️ 1.240 W · vandaag 6,2 kWh · stroom 18 ct`.
1. Open op je iPhone de app **Snelkoppelingen** en tik op **+**.
2. Voeg de actie **Inhoud van URL ophalen** toe en vul bovenstaand adres in (met jouw IP).
3. Voeg daarna **Toon resultaat** toe (of **Tekst** en dan **Toon melding**).
4. Houd je beginscherm ingedrukt, kies **+**, dan **Snelkoppelingen**, en zet de widget neer. Kies jouw snelkoppeling.


## Nieuw in 3.32.0: apparaat klaarzetten

De app leert al hoeveel stroom en tijd je wasmachine nodig heeft en rekent uit wat het beste moment is. Nu kan hij het apparaat ook zelf aanzetten.

Zo gebruik je het:
1. Maak een flow. Wanneer: je knop in de douche. Dan: kies bij Solis de actie **Zet apparaat klaar**. Vul bij Apparaat in: `Wasmachine` (de naam in Homey, met een aan/uit-knop of slimme stekker). Bij "niet starten voor (uur)" vul je bijvoorbeeld 9 in: dan start de wasmachine alleen overdag (tussen dat uur en 20:00). Bij "klaar voor (uur)" vul je een deadline in, of 0 voor geen deadline.
2. Laad de wasmachine en stel het programma in. Laat de stekker aan staan. De machine moet starten zodra hij stroom krijgt.
3. De app zet de stekker aan op het beste moment en stuurt een melding. Je ziet het ook op het dashboard bij Apparaten vandaag.
4. Bedoeld toch niet? Gebruik de actie **Zet apparaat niet meer klaar**.

De app weet zelf niet dat de machine geladen is. Daarom is de knop nodig. Wordt er binnen 36 uur geen goed moment gevonden, dan krijg je een melding.


## Nieuw in 3.33.0

1. **Wasadvies in de ochtend.** Rond 07:30 krijg je een melding met het beste moment voor de was overdag. Aan of uit te zetten bij Instellingen, groep "Apparaten en planner".
2. **Droger na de wasmachine.** In de actie "Zet apparaat klaar" is er een veld "Wacht tot dit apparaat klaar is". Zet je een droger klaar en vul je daar `Wasmachine` in, dan start de droger pas als de wasmachine klaar is (5 minuten geen stroomverbruik). De wasmachine moet dan wel bij "Apparaten volgen" staan.
3. **Zekeringbewaking.** Bij Instellingen vul je je hoofdzekering in (meestal 25 ampère). Kom je boven 85% dan krijg je een melding. Een klaargezet apparaat wacht ook even als hij de zekering te zwaar zou belasten.
4. **Kosten per wasbeurt.** Als de app een apparaat start, staat in de melding wat het kost en wat je bespaart ten opzichte van het duurste moment. Op het dashboard (Verbruik, Apparaten vandaag) staat hoeveel je in totaal bespaard hebt.

Dit zat er al in: boiler of kachel bij zonne-overschot (Instellingen, "Apparaten sturen op zonne-overschot"), sluipverbruik-melding, weekoverzicht op zondag, automatische back-up en de schatting voor het dynamische contract van 2027.


## Nieuw in 3.33.1: rustiger opstarten in de ochtend

's Ochtends en 's avonds heeft de omvormer te weinig zon om stabiel aan te blijven. Soms slaapt dan ook de datalogger. Voorheen telde dat als "verbinding weg". Nu geldt:
- Staat de zon lager dan 10 graden, dan zie je "Wacht op zon" in plaats van "niet beschikbaar". Er komt dan geen melding en geen flow "Verbinding weg".
- Rond zonsopkomst probeert de app elke 20 seconden opnieuw, zodat hij de omvormer meteen oppakt zodra die wakker wordt. Dieper in de nacht probeert hij veel minder vaak.
- Midden op de dag blijft een echt verbindingsprobleem gewoon gemeld worden.
- Een klaargezet apparaat start ook als er geen prijzen of zonneverwachting zijn.


## Nieuw in 3.33.2: leesbaarheid dashboard

Op de pagina's Overzicht, Dynamisch, Verbruik, Slim en Opties waren grote getallen en tabellen soms bijna onzichtbaar: donkere tekst op een donkere kaart. De donkere weergave lekte door naar de lichte weergave. Dat is opgelost. In licht en donker zijn alle kaarten en getallen nu goed te lezen. De titel "Dynamisch contract" is ingekort tot "Dynamisch", zodat hij het menu niet meer overlapt.


## Nieuw in 3.34.0: dashboard voor Kodi

De app geeft de gegevens nu ook kant-en-klaar door aan de Kodi-add-on "Solis Dashboard". Het adres is `http://IP-VAN-JE-HOMEY:8765/kodi.json`. Je hoeft in Homey niets in te stellen. Installeer daarna de add-on in Kodi (zie de README van de add-on).


## Nieuw in 3.35.0: het dashboard op je tv (Kodi), zonder Mac

De app tekent het dashboard nu zelf als afbeelding in dezelfde donkere stijl als op de Mac: de drie ringen met de stromende stippen, de kleurige cijfers, het grafiekje en de tegels. Je hebt dus geen Mac of beeldserver meer nodig om het op de tv te zien.

De afbeeldingen staan op `http://IP-VAN-JE-HOMEY:8765/beeld/page/stroom.png` (ook `zon`, `meer`, `inzicht`, `overzicht`, `dynamisch`, `verbruik`, `slim` en `instel`). Je kunt ze ook gewoon in een browser openen.

**Zo zet je het op de tv (Kodi-add-on 2.1.0):**
1. Installeer eerst deze app (3.35.0) op je Homey.
2. Kodi werkt de add-on "Solis Dashboard" zelf bij naar 2.1.0 (of installeer hem opnieuw uit het zip-bestand).
3. Open de add-on, kies Configureren en zet bij **Weergave** de keuze op **Beeld uit de Homey-app**.
4. Zet bij **Adres van het dashboard** het IP-adres van je Homey en laat de poort op 8765 staan.
5. Start de add-on. Links en rechts wisselen van pagina.

Goed om te weten: dit is een nagetekende versie van het webdashboard. De pagina's Stroom en Zon lijken sterk op de Mac. De andere pagina's hebben dezelfde stijl (donkere kaarten, kleuren, balken), maar een iets eenvoudiger indeling.


## Nieuw in 3.35.1: alle pagina's op de tv zoals op de Mac

Alle negen pagina's voor Kodi zijn nagetekend naar het webdashboard: Zon, Stroom, Details, Inzicht, Overzicht, Dynamisch, Verbruik, Slim en Opties. Ze hebben dezelfde kaarten, grafieken en kleuren, in de donkere stand. Installeren gaat zoals eerder: `npm install` en daarna `homey app install` in de uitgepakte map. De Kodi-add-on (2.1.1) hoeft niet opnieuw.


## Nieuw in 3.35.2: Nu per uur klopt

Bij "Nu per uur" (pagina Slim) stond een min-teken voor een bedrag dat je uitgeeft. Nu staat er "€ 0,05 kost per uur" als je stroom inkoopt en "+ € 0,14 verdiend per uur" als je teruglevert. Dit is aangepast in het webdashboard en op de tv.


## Nieuw in 3.35.3: lijnen op de Stroom-pagina

De twee lijnen op de pagina Stroom bewegen nu apart. De lijn van de zonnepanelen staat stil als er geen opwek is. De lijn naar het net blijft bewegen zolang je stroom inkoopt of teruglevert, ook als de zon uit is. Op de tv-afbeelding was dit al zo.


## Nieuw in 3.36.0: meldingen op de tv, prijsmelding met plan, maandrapport met plaatje

**Meldingen op de tv.** De app houdt de laatste meldingen bij op `http://IP-VAN-JE-HOMEY:8765/meldingen.json`. De Kodi-add-on (2.2.0) toont ze als melding bovenin beeld, ook tijdens een film. Welke meldingen je krijgt, bepaal je net als altijd bij Instellingen, Meldingen.

**Prijsmelding rond 14:00.** Zodra de prijzen van morgen bekend zijn, krijg je één melding met de goedkoopste en duurste uren. Heb je apparaten geleerd of ingesteld bij de planner, dan staat er ook het beste moment voor morgen bij.

**Maandrapport met plaatje.** Op de 1e van de maand gaat de flow-kaart **Maandrapport klaar** af, met de tags Rapport (tekst) en Plaatje (de pagina Overzicht als afbeelding). Zet er een actie achter die een mail of Telegram-bericht stuurt en voeg de tags toe. Zo krijg je het rapport in je mail.

**Onderweg kijken.** Zie het bestand `ONDERWEG-KIJKEN.md` in deze map.

## Nieuw in 3.37.0

- **Verbindingsdiagnose**: bij Opties, groep Koppelingen, staat nu hoe vaak de omvormer overdag onbereikbaar was (laatste 24 uur en 7 dagen), de laatste onderbreking en, als er een vast patroon is, wanneer het meestal gebeurt.
- **Verkeerslicht**: een flow-trigger "Verkeerslicht verandert" (kleur en reden) en een voorwaarde "Verkeerslicht is groen/oranje/rood". Groen = goed moment of goedkope stroom, rood = dure stroom of veel afname zonder zon. Handig voor een lamp.
- **Wasdag-advies**: elke zondag om 19:00 een melding met de zonnigste dag van de komende dagen (de app kijkt 3 dagen vooruit). Uit te zetten bij "Apparaten en planner".
- **Cijfers als CSV**: op het dashboard staat naast "Back-up downloaden" de link "Cijfers als CSV" (te openen in Excel of Numbers). Adres: `http://HOMEY:8765/export.csv`.
- **Apparaten klaarzetten vanaf de tv**: stel bij Instellingen, Dashboard, een pincode van 4 tot 8 cijfers in. Zonder pincode staat dit uit. In de Kodi-add-on (2.3.0) druk je op OK om een apparaat klaar te zetten. Na 5 foute pogingen is het 5 minuten geblokkeerd.
- **Voor de Lucent-skin**: `http://HOMEY:8765/lucent.json` (vast, klein overzicht) en `http://HOMEY:8765/beeld/kaart/stroom.png` (kaartje 1600 x 560 met de drie ringen). Alleen lezen, zonder wachtwoord.

## Nieuw in 3.38.0

- **Engelse versie**: bij Instellingen, Dashboard, staat nu *Taal* (Automatisch, Nederlands, English). Automatisch volgt de taal van je Homey. Geldt voor meldingen, het logboek, het webdashboard, de tv-afbeeldingen en `/lucent.json`. Wat nog niet vertaald is, blijft Nederlands (bijvoorbeeld de tekst die als flow-token terugkomt).
- **Dagterugblik**: op het dashboard (pagina Inzicht) kies je een datum; ook een flow-actie *Toon dagterugblik*.
- **Apparaat te lang aan**: melding als een gevolgd apparaat veel langer draait dan normaal (uit te zetten met *notifyApplianceLong*).
- **Jaarvergelijking**: op Overzicht een kolom met vorig jaar, zodra je een jaar aan gegevens hebt.
- **Echte terugverdientijd**: vanaf 60 dagen metingen rekent de app met je echte besparing in plaats van een schatting.
- **Web**: weerthema, periodekeuze (dag/week/maand/jaar), dagen vergelijken, installeerbaar als app, logboek met zoekveld, en uitleg bij getallen (tik op een tegel).
- **Flows**: zie `FLOWS-HANDLEIDING.md` voor elf recepten.

## Nieuw in 3.38.1

- **Details, grafiek**: onder elke maand staan nu de cijfers (oranje = opwek, paars = huis, in kWh). Nieuwe knop *Alles* toont alle maanden met gegevens, ook als je langer dan een jaar meet.

## Nieuw in 3.39.0: gaten in je geschiedenis vullen met je Vattenfall-gegevens

Heb je lege maanden op het dashboard (bijvoorbeeld van voor de installatie van je panelen)? Vattenfall heeft je verbruik wel bewaard. Zo vul je het in:

1. **Download je gegevens bij Vattenfall.** Log in op Mijn Vattenfall en zoek je verbruiksgegevens (meestal onder *Verbruik* of *Mijn gegevens*). Kies *Downloaden* en kies Excel of CSV. Kies per dag, per uur of per kwartier, niet de factuur en niet maandtotalen. De tekst op het scherm kan anders zijn; kijk naar een knop of link met *Download*, *Exporteren* of *Excel*.
2. **Open de Solis-app in Homey**: Instellingen van de app, en ga naar het kopje **Gegevens importeren (Vattenfall)**.
3. **Kies het bestand** en druk op **Controleren**. Er verschijnt een voorbeeld: van welke datum tot welke datum het bestand loopt, hoeveel kWh er is afgenomen en teruggeleverd, welke kolommen ik heb gebruikt, en hoeveel dagen nieuw, aangevuld of overgeslagen worden. Staat er *Let op*, lees dat dan eerst.
4. **Klopt het voorbeeld?** Druk dan op **Importeren**. Staat er niets of iets raars, importeer dan niet.
5. **Kijk op het dashboard** bij Details, knop *Alles*: de lege maanden zijn nu gevuld.

Wat er gebeurt:
- Dagen die de app **zelf heeft gemeten** blijven zoals ze zijn. Die worden nooit overschreven.
- Dagen die nog geen meting hebben, of die uit Homey zijn overgenomen of geschat, krijgen afname, teruglevering en verbruik uit het bestand. Nieuwe dagen worden toegevoegd.
- Het verbruik van het huis is afname plus eigen opwek min teruglevering. Voor dagen vóór je panelen is dat gewoon de afname.
- De euro's worden berekend met de tarieven die je bij Instellingen hebt ingevuld (vaste prijs). Vul die eerst in als je bedragen wilt zien.
- De app bewaart maximaal 800 dagen. Is je bestand langer, dan vallen de oudste dagen af.

**Ongedaan maken:** druk op **Ongedaan maken** onder hetzelfde kopje. Dan verdwijnen de toegevoegde dagen en komen de oude waarden terug. Dat kan voor de laatste import.

**Wordt je bestand niet herkend?** Je krijgt een duidelijke melding. Ik ken het exacte bestand van Vattenfall niet, dus dit kan voorkomen. Stuur het bestand dan naar de maker van de app, dan wordt de herkenning aangepast. Een oud `.xls`-bestand open je eerst in Excel en sla je het op als `.xlsx` of CSV.

Wat de app herkent: CSV (scheidingsteken ; , of tab, decimale komma of punt) en Excel (.xlsx); datums als 01-03-2026, 2026-03-01 of een Excel-datum; waarden per dag, per uur of per kwartier (wordt per dag opgeteld); kolommen voor afname en teruglevering, ook gesplitst in normaal en dal; meterstanden (de app neemt het verschil per dag); kWh en Wh.

## Nieuw in 3.39.1

- **Vattenfall-bestand herkend**: het dagbestand van Mijn Vattenfall (kolommen *Verbruik 1/2 (kWh)* en *Teruglevering 3/4 (kWh)*, met de meterstanden ernaast) wordt nu goed gelezen. Vattenfall geeft hele kWh per dag, dus kleine dagwaarden zijn afgerond. De totalen kloppen met je meterstanden.

## Nieuw in 3.40.0

- **Weer op de Zon-pagina**: wolken, regen en sneeuw bewegen over de achtergrond en de zon wordt gedimd als het bewolkt, regenachtig of sneeuwachtig is. Zet het aan met de stijl *Weer* (Instellingen, Dashboard) of in het menu rechtsonder (de drie puntjes, *Weer*). Het gebruikt de weersverwachting van vandaag. Wil je het even bekijken? Zet `?wx=regen`, `?wx=bewolkt` of `?wx=sneeuw` achter het adres.

## Nieuw in 3.41.0

- **Weerplaatjes op de tv (Kodi)**: de Zon-pagina op de tv toont nu ook wolken, regen en sneeuw.
- **Foutenrapport en installatiecontrole**: één knop maakt een rapport dat je kunt delen (zonder wachtwoorden). De installatiecontrole zoekt zelf wat er mis is. Ook is er een welkomstkaart voor de eerste keer, en een voorbereiding op andere merken omvormers.
- **Ochtendkaart**: elke ochtend een plaatje met de verwachte opbrengst, de 3 goedkoopste uren, wasadvies en het verkeerslicht. Zet *Ochtendsamenvatting* aan. In flows is er de trigger *Ochtendkaart*.
- **Vakantie-overzicht**: bij terugkomst krijg je "Welkom thuis" met wat de slimme sturing heeft bespaard en eventuele storingen. In flows: trigger *Vakantie-overzicht*.
- **Dashboard-wachtwoord**: stel een wachtwoord in bij Instellingen (zie `docs/WACHTWOORD.md`). Let op: de Kodi-add-on kan het wachtwoord nog niet meesturen. Gebruik je Kodi, laat dan het veld *Token* leeg.
- **Batterij-rekenhulp**: op de Overzicht-pagina zie je wat een thuisbatterij van 2,5, 5 of 10 kWh (of je eigen grootte) zou opleveren. Dit werkt pas na ongeveer 30 dagen uurgegevens.
- **Factuur voorinvullen**: bij Factuurcontrole kies je je factuurbestand en de velden worden ingevuld. Er wordt niets opgeslagen.
- **Terugleverwaarschuwing**: een melding als de terugleverprijs negatief wordt, samengevoegd met de bestaande melding.

## Nieuw in 3.42.0

- **Slim starten (flows)**: trigger *Begin van het goedkoopste of zonnigste blok* en conditie *Nu is in het goedkoopste of zonnigste blok*. Kies de duur (1-12 uur) en binnen hoeveel uur. "Goedkoopste" werkt alleen met een dynamisch contract. Handig voor wasmachine, droger, boiler.
- **Overschot-schakelaar**: triggers *Zonne-overschot is aan (stabiel)* en *Zonne-overschot is uit (stabiel)* (standaard aan vanaf 1000 W na 5 minuten, uit onder 300 W). Bruikbaar voor een laadpaal of warmtepomp. Je koppelt het zelf aan je apparaat in een flow.
- **Paneelcheck**: een melding als je opbrengst op een zonnige dag duidelijk onder je eigen norm ligt (2 zonnige dagen na elkaar, of heel erg laag). Zet aan/uit in de instellingen.
- **Back-up**: actie *Maak nu een back-up*, en optioneel elke zondag automatisch. Er staan geen wachtwoorden in.
- **Samenvatting als tekst**: actie *Maak samenvatting*, handig voor Google of Alexa via Homey.
- **Terugverdientijd en Spaarpot**: nieuwe tv-tabbladen en een pagina `/inzichten` op het dashboard. Vul het aankoopbedrag van je panelen in.
- **Contractvergelijker**: wat vast, variabel en dynamisch gekost zou hebben, op basis van je echte verbruik. Heb je minstens 14 dagen gegevens nodig. Vaste maandkosten zijn niet meegerekend.
- **Jaar op jaar** per maand, met uitleg of het zonniger of grijzer was.
- **Kinderpagina**: je opbrengst omgerekend naar kilometers, wasbeurten, koffie en een vraag van de dag.
- **Demo-stand** (instelling *demoMode*): nepgegevens om te laten zien. Zie `docs/DEMO.md`. Let op: zet hem weer uit voor je echte gegevens.
- **Voorbereiding andere merken**: sjabloon in `lib/brands/_sjabloon.js`, uitleg in `docs/NIEUW-MERK.md`. Er is nog geen echte koppeling met andere merken.
