'use strict';
// Gegevens en back-up voor de instellingenpagina en het dashboard
module.exports = {
  async dashGet({ homey, query }) {
    return homey.app.dashProxy('GET', query && query.u, null);
  },
  async dashPost({ homey, body }) {
    return homey.app.dashProxy(body && body.m === 'GET' ? 'GET' : 'POST', body && body.u, body && body.body);
  },
  async getWidget({ homey }) {
    return homey.app.getWidgetData();
  },
  async getBackup({ homey }) {
    return homey.app.getBackup();
  },
  async importHistory({ homey }) {
    return homey.app.importHistory();
  },
  async importSolisCloud({ homey }) {
    return homey.app.importSolisCloud();
  },
  async importHomeyEnergy({ homey }) {
    return { text: await homey.app.importHomeyEnergy() };
  },
  async homeyEnergyCheck({ homey }) {
    return { text: await homey.app.homeyEnergyCheck() };
  },
  async ledringTest({ homey }) {
    return { text: await homey.app.ledringTest() };
  },
  async testNotification({ homey }) {
    return { text: await homey.app.testNotification() };
  },
  async listDevices({ homey }) {
    return homey.app.listDevices();
  },
  async vattenfallUpload({ homey, body }) {
    return homey.app.vattenfallUpload(body);
  },
  async vattenfallApply({ homey, body }) {
    return homey.app.vattenfallApply(body);
  },
  async vattenfallUndo({ homey }) {
    return homey.app.vattenfallUndo();
  },
  async bugReport({ homey }) {
    return homey.app.bugReport();
  },
  async runDoctor({ homey }) {
    return homey.app.runDoctor();
  },
  async restoreBackup({ homey, body }) {
    const days = await homey.app.restoreBackup(body);
    return { ok: true, days };
  },
};
