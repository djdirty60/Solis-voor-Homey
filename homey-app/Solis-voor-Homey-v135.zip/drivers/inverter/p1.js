'use strict';

/**
 * TESTVERSIE: netvermogen rechtstreeks uit de P1-dongle lezen (via de Homey Web API).
 * Staat standaard uit. Mislukt iets, dan schrijft de app dat in het logboek en blijft de flow
 * "Geef netvermogen door" gewoon werken.
 */


function list(devices) {
  return Object.values(devices || {});
}

function hasPower(d) {
  return Array.isArray(d.capabilities) && d.capabilities.includes('measure_power');
}

module.exports = {
  async p1Candidates() {
    const api = await this.getAppApi();
    const devices = list(await api.devices.getDevices());
    return { api, devices: devices.filter(hasPower) };
  },

  pickP1(devices, name) {
    const n = (name || '').trim().toLowerCase();
    if (n) return devices.find((d) => (d.name || '').toLowerCase().includes(n)) || null;
    return devices.find((d) => /p1|dongle|energy/i.test((d.name || '') + ' ' + (d.driverId || ''))) || null;
  },

  async startP1() {
    this.stopP1();
    const s = this.getSettings();
    if (s.p1Enabled !== true) { this.p1Status = 'uit'; return; }
    try {
      const { devices } = await this.p1Candidates();
      const dev = this.pickP1(devices, s.p1Name);
      if (!dev) {
        this.p1Status = 'niet gevonden';
        this.logEvent('P1: apparaat niet gevonden. Gebruik "Zoek P1-apparaten".');
        return;
      }
      const onValue = (v) => {
        if (typeof v === 'number') {
          this.p1At = Date.now();
          this.reportNetPower(v).catch(this.error);
        }
      };
      this.p1Instance = dev.makeCapabilityInstance('measure_power', onValue);
      this.p1Device = dev;
      this.p1Status = 'actief: ' + dev.name;
      this.logEvent('P1 gekoppeld: ' + dev.name);
      const cur = dev.capabilitiesObj && dev.capabilitiesObj.measure_power && dev.capabilitiesObj.measure_power.value;
      onValue(cur);
      // vangnet: als de updates stilvallen, toch elke 10 s de waarde lezen
      this.p1Timer = this.homey.setInterval(() => {
        const v = this.p1Device && this.p1Device.capabilitiesObj && this.p1Device.capabilitiesObj.measure_power
          && this.p1Device.capabilitiesObj.measure_power.value;
        if (typeof v === 'number' && Date.now() - (this.p1At || 0) > 10000) onValue(v);
      }, 10000);
    } catch (e) {
      this.p1Status = 'fout: ' + e.message;
      this.error('P1 koppelen mislukt:', e.message);
      this.logEvent('P1 koppelen mislukt: ' + e.message.slice(0, 60));
    }
  },

  stopP1() {
    if (this.p1Timer) this.homey.clearInterval(this.p1Timer);
    this.p1Timer = null;
    try { if (this.p1Instance && this.p1Instance.destroy) this.p1Instance.destroy(); } catch (e) { /* niet kritiek */ }
    this.p1Instance = null;
    this.p1Device = null;
  },

  /** Gevolgde apparaten (bijv. wasmachine): elke 20 s hun vermogen lezen. */
  async refreshApps() {
    const s0 = this.getSettings();
    if (s0.basicMode === true) { this.appPower = {}; return; }
    let names = String(s0.trackDevices || '').split(',').map((x) => x.trim()).filter(Boolean);
    if (!names.length && s0.trackAuto !== true) { this.appPower = {}; return; }
    try {
      if (!this.appDevices || Date.now() - (this.appDevicesAt || 0) > 10 * 60 * 1000) {
        this.appDevices = (await this.p1Candidates()).devices;
        this.appDevicesAt = Date.now();
      }
      if (s0.trackAuto === true) {
        const extra = this.appDevices.filter((d) => d.class === 'socket' && Array.isArray(d.capabilities) && d.capabilities.includes('onoff') && d.name).map((d) => d.name);
        names = Array.from(new Set(names.concat(extra)));
      }
      const out = {};
      // De lijst met apparaten is tot 10 minuten oud: die dient alleen om de juiste apparaten te vinden.
      // De waarden (vermogen, kWh-teller) halen we elke keer vers op, anders lijkt een wasmachine
      // tussen twee trommelslagen door 'klaar' (3.61.2).
      const api = await this.getAppApi();
      const fresh = async (d) => {
        if (!d || !d.id || !api.devices || typeof api.devices.getDevice !== 'function') return d;
        try { return (await api.devices.getDevice({ id: d.id })) || d; } catch (e) { return d; }
      };
      for (const n of names) {
        const nn = n.trim().toLowerCase();
        const nm = (d) => (d.name || '').trim().toLowerCase();
        const plug = this.appDevices.filter((d) => !/profiler/i.test(d.name || ''));
        const dev = await fresh(plug.find((d) => nm(d) === nn) || plug.find((d) => nm(d).includes(nn)));
        // Power Profiler (andere Homey-app): "<naam> Profiler" heeft al een gemiddelde beurt geleerd
        const pr = this.appDevices.find((d) => nm(d).replace(/\s+/g, ' ') === nn + ' profiler');
        const pc = pr && pr.capabilitiesObj ? pr.capabilitiesObj : null;
        const pv = (k) => (pc && pc[k] && typeof pc[k].value === 'number' ? pc[k].value : null);
        this.profilerData = this.profilerData || {};
        if (pc && pv('profile_cycle_count') !== null) this.profilerData[n] = { cycles: pv('profile_cycle_count'), min: pv('profile_avg_duration'), kwh: pv('profile_avg_energy') };
        const v = dev && dev.capabilitiesObj && dev.capabilitiesObj.measure_power && dev.capabilitiesObj.measure_power.value;
        if (typeof v === 'number') out[n] = v;
        // de kWh-teller van de stekker: daarmee klopt het verbruik van een beurt ook als de app tussendoor herstart
        const m = dev && dev.capabilitiesObj && dev.capabilitiesObj.meter_power && dev.capabilitiesObj.meter_power.value;
        this.appClass = this.appClass || {};
        if (dev && dev.class) this.appClass[n] = dev.class;
        this.appMeter = this.appMeter || {};
        if (typeof m === 'number') this.appMeter[n] = m;
      }
      this.appPower = out;
      this.checkApplianceDone(out);
    } catch (e) {
      this.appPower = {};
      if (!this.appErrLogged) { this.appErrLogged = true; this.logEvent('Apparaten volgen mislukt: ' + String(e.message).slice(0, 50)); }
    }
  },

  /** Alle apparaten met vermogensmeting, voor de keuzelijst bij Instellingen. Stekkers eerst. */
  async listPowerDevices() {
    const { devices } = await this.p1Candidates();
    const rows = devices.filter((d) => d.name).map((d) => {
      const co = d.capabilitiesObj || {};
      const w = co.measure_power && typeof co.measure_power.value === 'number' ? Math.round(co.measure_power.value) : null;
      return { name: String(d.name).replace(/,/g, ' '), cls: d.class || '', socket: d.class === 'socket', watts: w, canSwitch: Array.isArray(d.capabilities) && d.capabilities.includes('onoff') };
    });
    rows.sort((a, b) => (b.socket - a.socket) || a.name.localeCompare(b.name, 'nl'));
    return rows;
  },

  async listP1() {
    let text;
    try {
      const { devices } = await this.p1Candidates();
      text = devices.length ? devices.map((d) => d.name).join(' | ') : 'Geen apparaten met vermogen gevonden.';
    } catch (e) {
      text = 'Niet gelukt: ' + e.message;
    }
    this.logEvent('P1-zoeken: ' + text.slice(0, 80));
    try { await this.sendNotification('Solis apparaten met vermogen: ' + text); } catch (e) { this.error(e.message); }
    return text;
  },
};
