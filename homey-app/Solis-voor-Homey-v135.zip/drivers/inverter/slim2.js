'use strict';

/**
 * Slim starten, overschot-schakelaar, paneelcheck, back-up op afroep en samenvatting als tekst.
 * Wordt aan InverterDevice gehangen (zie device.js).
 */
const startwindow = require('../../lib/startwindow');
const surplusSwitch = require('../../lib/surplusswitch');
const panelcheck = require('../../lib/panelcheck');
const summaryText = require('../../lib/summarytext');
const anomaly = require('../../lib/anomaly');
const forecast = require('../../lib/forecast');
const i18n = require('../../lib/i18n');
const { zoned, isSunday } = require('../../lib/timeutil');

const num = (v, def) => (v !== undefined && v !== null && v !== '' && Number.isFinite(Number(v)) ? Number(v) : def);

module.exports = {
  // ---------- slim starten: goedkoopste of zonnigste blok ----------
  /** Beste blok voor de gekozen duur. args = { uren, binnen, bron }. null = te weinig gegevens. */
  windowFor(args) {
    const a = args || {};
    const bron = a.bron === 'zon' ? 'zon' : 'prijs';
    const s = this.getSettings();
    const entries = [].concat((this.todayPrices && this.todayPrices.entries) || [], (this.tomorrowPrices && this.tomorrowPrices.entries) || []);
    if (bron === 'prijs' && (this.currentContract() !== 'dynamisch' || !entries.length)) return null;
    const tz = this.homey.clock.getTimezone();
    const hourly = (this.forecastData && this.forecastData.hourly) || {};
    const factor = this.learnedFactor();
    const kWp = Number(s.kWp) || 2.5;
    const maxW = Number(s.maxPower) || 2500;
    const sunW = (t) => {
      const z = zoned(t, tz);
      const rad = hourly[z.date + 'T' + String(z.h).padStart(2, '0') + ':00'];
      return typeof rad === 'number' ? forecast.potentialW(rad, factor, kWp, maxW) : null;
    };
    return startwindow.best({
      mode: bron, hours: a.uren, withinH: a.binnen, entries, addCost: Number(s.fixedCosts) || 0, sunW, now: Date.now(),
    });
  },

  windowInside(args) {
    const w = this.windowFor(args);
    return !!(w && w.inside);
  },

  /** Gaat elke ronde langs de flows die "begin van het goedkoopste/zonnigste blok" gebruiken en meldt het begin één keer. */
  async checkWindows() {
    const card = this.homey.flow.getDeviceTriggerCard('window_started');
    let list = [];
    try { list = (await card.getArgumentValues()) || []; } catch (e) { return; }
    if (!list.length) return;
    this.windowFired = this.windowFired || {};
    const tz = this.homey.clock.getTimezone();
    const done = {};
    for (const a of list) {
      const argsKey = [Math.round(num(a.uren, 2)), Math.round(num(a.binnen, 24)), a.bron === 'zon' ? 'zon' : 'prijs'].join('-');
      if (done[argsKey]) continue;
      done[argsKey] = true;
      const w = this.windowFor(a);
      if (!w || !w.inside) continue;
      const k = startwindow.key(w, argsKey);
      if (this.windowFired[k]) continue;
      this.windowFired[k] = Date.now();
      const z = (ms) => { const t = zoned(ms, tz); return String(t.h).padStart(2, '0') + ':' + String(t.m).padStart(2, '0'); };
      this.logEvent(startwindow.text(w, tz));
      card.trigger(this, {
        van: z(w.from), tot: z(w.to), uren: w.hours, gemiddelde: w.mode === 'prijs' ? Math.round(w.avg * 10000) / 100 : w.avg,
      }, { argsKey }).catch(this.error);
    }
    for (const k of Object.keys(this.windowFired)) if (Date.now() - this.windowFired[k] > 48 * 3600000) delete this.windowFired[k];
  },

  // ---------- overschot-schakelaar ----------
  checkSurplusSwitch() {
    const s = this.getSettings();
    this.surplusSt = this.surplusSt || surplusSwitch.create();
    const w = this.online === false ? 0 : Number(this.getCapabilityValue('inverter_surplus')) || 0;
    const ev = surplusSwitch.step(this.surplusSt, {
      w,
      onW: num(s.surplusSwitchOnW, 1000),
      offW: num(s.surplusSwitchOffW, 300),
      onMin: num(s.surplusSwitchOnMin, 5),
      offMin: num(s.surplusSwitchOffMin, 5),
      now: Date.now(),
    });
    if (ev) {
      this.logEvent('Overschot-schakelaar ' + (ev === 'on' ? 'aan' : 'uit') + ' (' + Math.round(w) + ' W).');
      this.homey.flow.getDeviceTriggerCard('surplus_' + ev).trigger(this, { surplus: Math.round(w) }).catch(this.error);
    }
    return ev;
  },

  surplusSwitchOn() {
    return !!(this.surplusSt && this.surplusSt.on);
  },

  // ---------- paneelcheck ----------
  checkPanelUnderperform(date) {
    try {
      const s = this.getSettings();
      if (s.notifyUnderperform === false) return null;
      const h = this.history || [];
      const r = panelcheck.check(h, date, { pct: num(s.underperformPct, 30) });
      if (!r) return null;
      const last = this.getStoreValue('lastUnderperform') || 0;
      if (Date.now() - last < 3 * 24 * 3600 * 1000) return null;
      this.setStoreValue('lastUnderperform', Date.now()).catch(this.error);
      const text = panelcheck.text(r);
      this.logEvent('Paneelcheck: ' + r.dropPct + ' % onder de norm op ' + date + '.');
      this.homey.flow.getDeviceTriggerCard('panel_underperform').trigger(this, {
        verwacht: r.expected, werkelijk: r.kwh, afwijking: r.dropPct, tekst: i18n.tr(text),
      }).catch(this.error);
      // is de opbrengst zo laag dat de afwijkingsmelding al afging (< 50 %), dan niet nog een melding
      const ya = anomaly.yieldAnomaly(h, date, Number(s.kWp) || 2.5);
      if (!ya) this.notify('underperform', text);
      return r;
    } catch (e) { this.error('Paneelcheck mislukt:', e.message); return null; }
  },

  // ---------- back-up op afroep en wekelijks ----------
  async backupUrl() {
    const s = this.getSettings();
    if (s.dashboardEnabled === false) return null;
    try {
      const addr = await this.homey.cloud.getLocalAddress();
      const ip = String(addr || '').split(':')[0];
      return ip ? 'http://' + ip + ':' + (Number(s.dashboardPort) || 8765) + '/backup-download' : null;
    } catch (e) { return null; }
  },

  /** Bewaart een kopie in de app-opslag van Homey (met de vorige als reserve). */
  async backupNow() {
    const data = this.backupData(); // zonder wachtwoorden
    const days = (this.history || []).length;
    if (this.homey.settings) {
      const prev = this.homey.settings.get('autoBackup');
      if (prev && prev.data) this.homey.settings.set('autoBackupPrev', prev);
      this.homey.settings.set('autoBackup', { t: Date.now(), days, data });
    }
    await this.setStoreValue('lastAutoBackup', this.todayString()).catch(this.error);
    this.logEvent('Back-up gemaakt (' + days + ' dagen).');
    const url = await this.backupUrl();
    const text = 'Back-up gemaakt (' + days + ' dagen) en bewaard in Homey.' + (url ? ' Wil je hem ook op je computer? Download hem op ' + url + ' (geen wachtwoorden in het bestand).' : '');
    return { text, days, url };
  },

  async makeBackup() {
    const r = await this.backupNow();
    try { await this.sendNotification('Solis: ' + r.text); } catch (e) { this.error(e.message); }
    return true;
  },

  /** Elke zondag na 10:00 een back-up en een melding, als je dat hebt aangezet. */
  async checkWeeklyBackup() {
    const s = this.getSettings();
    if (s.notifyBackupWeekly !== true) return;
    const today = this.todayString();
    if (!isSunday(today) || this.currentMinutes() < 10 * 60 || this.getStoreValue('lastWeeklyBackup') === today) return;
    if (!(this.history || []).length) return;
    await this.setStoreValue('lastWeeklyBackup', today).catch(this.error);
    const r = await this.backupNow();
    await this.notifyText('Wekelijkse back-up. ' + r.text);
  },

  // ---------- samenvatting als tekst ----------
  async makeSummary() {
    const d = this.widgetData();
    const text = i18n.tr(summaryText.build(d));
    const c0 = d.light && d.light.color ? String(d.light.color) : '';
    const color = i18n.getLang() === 'en' ? ({ groen: 'green', oranje: 'orange', rood: 'red' }[c0] || c0) : c0;
    this.logEvent('Samenvatting gemaakt.');
    await this.homey.flow.getDeviceTriggerCard('summary_ready').trigger(this, {
      text, kwh: Math.round((Number(d.todayKwh) || 0) * 10) / 10, watts: Math.round(Number(d.watts) || 0), light: color,
    });
    return true;
  },
};
