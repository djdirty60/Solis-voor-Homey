'use strict';

const Homey = require('homey');
const i18n = require('./lib/i18n');

module.exports = class SolisApp extends Homey.App {
  /** Back-up en terugzetten (gebruikt door de instellingenpagina en het dashboard). */
  firstDevice() {
    return this.homey.drivers.getDriver('inverter').getDevices()[0] || null;
  }

  getBackup() {
    const dev = this.firstDevice();
    if (!dev) throw new Error('Nog geen apparaat toegevoegd.');
    return dev.backupDownload();
  }

  async importHistory() {
    const dev = this.firstDevice();
    if (!dev) throw new Error('Nog geen apparaat toegevoegd.');
    return dev.importFromHomey();
  }

  async importHomeyEnergy() {
    const dev = this.firstDevice();
    if (!dev) throw new Error('Nog geen apparaat toegevoegd.');
    return dev.importHomeyEnergy();
  }

  async homeyEnergyCheck() {
    const dev = this.firstDevice();
    if (!dev) throw new Error('Nog geen apparaat toegevoegd.');
    return dev.homeyEnergyCheck();
  }

  async ledringTest() {
    const dev = this.homey.drivers.getDriver('inverter').getDevices()[0];
    if (!dev) return 'Er is nog geen omvormer toegevoegd.';
    return dev.ledringTest();
  }

  async testNotification() {
    const dev = this.firstDevice();
    if (!dev) throw new Error('Nog geen apparaat toegevoegd.');
    return dev.testNotification();
  }

  async listDevices() {
    const dev = this.firstDevice();
    if (!dev) throw new Error('Nog geen apparaat toegevoegd.');
    return dev.listPowerDevices();
  }

  async bugReport() {
    const dev = this.firstDevice();
    if (!dev) throw new Error('Nog geen apparaat toegevoegd.');
    return dev.bugReport();
  }

  async runDoctor() {
    const dev = this.firstDevice();
    if (!dev) throw new Error('Nog geen apparaat toegevoegd.');
    return dev.runDoctor();
  }

  async restoreBackup(b) {
    const dev = this.firstDevice();
    if (!dev) throw new Error('Nog geen apparaat toegevoegd.');
    return dev.restoreData(b);
  }

  /** Gegevens voor de dashboard-widgets. */
  /** Dashboard via Homey (instellingenpagina), ook buiten huis. */
  async dashProxy(method, u, body) {
    const dev = this.homey.drivers.getDriver('inverter').getDevices()[0];
    if (!dev || !dev.dashboard) return { status: 503, type: 'application/json', body: JSON.stringify({ error: 'Het dashboard staat uit (Instellingen, Dashboard).' }) };
    return dev.dashboard.internal(method, String(u || ''), body);
  }

  getWidgetData() {
    try {
      const dev = this.homey.drivers.getDriver('inverter').getDevices()[0];
      if (!dev) return { available: false };
      return dev.widgetData();
    } catch (e) {
      return { available: false, error: e.message };
    }
  }

  async onInit() {
    this.log('Solis voor Homey gestart');
    let cfgTimer = null;
    this.homey.settings.on('set', (key) => {
      if (key !== 'cfg') return;
      if (cfgTimer) this.homey.clearTimeout(cfgTimer);
      cfgTimer = this.homey.setTimeout(() => {
        try { this.homey.drivers.getDriver('inverter').getDevices().forEach((dv) => dv.applySettings()); } catch (e) { this.error(e.message); }
      }, 500);
    });
    const dev = (args) => args.device;
    this.homey.flow.getActionCard('set_mode').registerRunListener(async (args) => dev(args).setWantedMode(args.mode));
    this.homey.flow.getActionCard('emergency').registerRunListener(async (args) => dev(args).emergency());
    this.homey.flow.getActionCard('report_net_power').registerRunListener(async (args) => dev(args).reportNetPower(Number(args.power)));
    this.homey.flow.getActionCard('report_price').registerRunListener(async (args) => dev(args).reportPrice(Number(args.price)));
    this.homey.flow.getActionCard('arm_appliance').registerRunListener(async (args) => dev(args).armAppliance(args.apparaat, Number(args.uiterlijk) || 0, Number(args.vanaf) || 0, String(args.wacht_op || '').trim(), Number(args.duur) || 0));
    this.homey.flow.getActionCard('disarm_appliance').registerRunListener(async (args) => dev(args).disarmAppliance(args.apparaat));
    this.homey.flow.getActionCard('send_report').registerRunListener(async (args) => dev(args).sendReport(true));
    this.homey.flow.getActionCard('show_log').registerRunListener(async (args) => dev(args).showLog());
    this.homey.flow.getActionCard('restart_connection').registerRunListener(async (args) => dev(args).restartConnection());
    this.homey.flow.getActionCard('show_year').registerRunListener(async (args) => dev(args).showYear());
    this.homey.flow.getActionCard('run_check').registerRunListener(async (args) => dev(args).healthCheck(true));
    this.homey.flow.getActionCard('list_p1').registerRunListener(async (args) => dev(args).listP1());
    this.homey.flow.getActionCard('day_review').registerRunListener(async (args) => dev(args).dayReviewText(args.datum));
    this.homey.flow.getActionCard('show_month').registerRunListener(async (args) => dev(args).showMonth());
    this.homey.flow.getActionCard('test_notification').registerRunListener(async (args) => { await dev(args).testNotification(); return true; });
    this.homey.flow.getActionCard('self_test').registerRunListener(async (args) => dev(args).selfTest());
    this.homey.flow.getActionCard('send_weekly').registerRunListener(async (args) => dev(args).sendWeekly());
    this.homey.flow.getActionCard('import_history').registerRunListener(async (args) => { await dev(args).importFromHomey(); return true; });
    this.homey.flow.getActionCard('set_vacation').registerRunListener(async (args) => dev(args).setVacation(args.state === 'on'));
    this.homey.flow.getActionCard('make_backup').registerRunListener(async (args) => dev(args).makeBackup());
    this.homey.flow.getActionCard('make_summary').registerRunListener(async (args) => dev(args).makeSummary());
    this.homey.flow.getConditionCard('in_window').registerRunListener(async (args) => dev(args).windowInside(args));
    this.homey.flow.getConditionCard('surplus_switch_on').registerRunListener(async (args) => dev(args).surplusSwitchOn());
    this.homey.flow.getDeviceTriggerCard('window_started').registerRunListener(async (args, state) => state.argsKey === [Math.round(Number(args.uren) || 2), Math.round(Number(args.binnen) || 24), args.bron === 'zon' ? 'zon' : 'prijs'].join('-'));
    this.homey.flow.getConditionCard('vacation_on').registerRunListener(async (args) => dev(args).vacationOn());
    this.homey.flow.getConditionCard('traffic_light_is').registerRunListener(async (args) => dev(args).lightNow().color === args.kleur);
    this.homey.flow.getConditionCard('good_moment').registerRunListener(async (args) => dev(args).goodMoment(Number(args.watts)));
    this.homey.flow.getConditionCard('has_surplus').registerRunListener(async (args) => (Number(dev(args).getCapabilityValue('inverter_surplus')) || 0) >= Number(args.watts));
    this.homey.flow.getConditionCard('price_below').registerRunListener(async (args) => dev(args).price !== null && dev(args).price < Number(args.price));
    this.homey.flow.getDeviceTriggerCard('ledring_color').registerRunListener(async (args, state) => args.kleur === state.kleur);
    this.homey.flow.getDeviceTriggerCard('surplus_above').registerRunListener(async (args, state) => state.surplus >= Number(args.watts) && state.prev < Number(args.watts));
    this.homey.flow.getConditionCard('mode_is').registerRunListener(async (args) => dev(args).getCapabilityValue('inverter_effective') === args.mode
      || (args.mode === 'auto' && dev(args).getCapabilityValue('inverter_mode') === 'auto'));
  }
};
